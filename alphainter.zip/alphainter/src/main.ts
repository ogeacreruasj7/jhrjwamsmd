import './style.css';

// Initialize any interactive elements
document.addEventListener('DOMContentLoaded', () => {
  // Mobile menu toggle
  const mobileMenuBtn = document.getElementById('mobile-menu-btn');
  const navMenu = document.getElementById('nav-menu');

  if (mobileMenuBtn && navMenu) {
    mobileMenuBtn.addEventListener('click', () => {
      navMenu.classList.toggle('open');

      const icon = mobileMenuBtn.querySelector('i');
      if (icon) {
        if (navMenu.classList.contains('open')) {
          icon.classList.remove('fa-bars');
          icon.classList.add('fa-times');
        } else {
          icon.classList.remove('fa-times');
          icon.classList.add('fa-bars');
        }
      }
    });
  }

  // Add smooth scrolling for anchor links
  const anchorLinks = document.querySelectorAll('a[href^="#"]');

  for (const link of anchorLinks) {
    link.addEventListener('click', function(this: HTMLAnchorElement, e: Event) {
      e.preventDefault();

      const targetId = this.getAttribute('href') as string;
      const targetElement = document.querySelector(targetId);

      if (targetElement) {
        targetElement.scrollIntoView({
          behavior: 'smooth'
        });

        // Close mobile menu if open
        if (navMenu?.classList.contains('open') && mobileMenuBtn) {
          navMenu.classList.remove('open');
          const icon = mobileMenuBtn.querySelector('i');
          if (icon) {
            icon.classList.remove('fa-times');
            icon.classList.add('fa-bars');
          }
        }
      }
    });
  }

  // Form submission handling
  const contactForm = document.getElementById('contact-form') as HTMLFormElement;

  if (contactForm) {
    contactForm.addEventListener('submit', (e: Event) => {
      e.preventDefault();
      alert('Your message has been sent. We will contact you soon!');
      contactForm.reset();
    });
  }

  // Gallery functionality
  const filterBtns = document.querySelectorAll('.filter-btn');
  const galleryItems = document.querySelectorAll('.gallery-item');
  const modal = document.getElementById('gallery-modal');
  const modalImg = document.getElementById('modal-image') as HTMLImageElement | null;
  const closeModal = document.querySelector('.modal-close');
  const galleryBtns = document.querySelectorAll('.gallery-btn');

  // Gallery filtering
  if (filterBtns.length > 0 && galleryItems.length > 0) {
    for (const btn of filterBtns) {
      btn.addEventListener('click', function(this: HTMLElement) {
        // Remove active class from all buttons
        for (const b of filterBtns) {
          b.classList.remove('active');
        }

        // Add active class to clicked button
        this.classList.add('active');

        // Get filter value
        const filter = this.getAttribute('data-filter');

        // Filter gallery items
        for (const item of galleryItems) {
          if (filter === 'all' || item.getAttribute('data-category') === filter) {
            (item as HTMLElement).style.display = 'block';
          } else {
            (item as HTMLElement).style.display = 'none';
          }
        }
      });
    }
  }

  // Gallery modal
  if (galleryBtns.length > 0 && modal && modalImg) {
    for (const btn of galleryBtns) {
      btn.addEventListener('click', function(this: HTMLElement) {
        const imgSrc = this.getAttribute('data-image');
        if (imgSrc) {
          modalImg.src = imgSrc;
          (modal as HTMLElement).style.display = 'block';
        }
      });
    }

    if (closeModal) {
      closeModal.addEventListener('click', () => {
        (modal as HTMLElement).style.display = 'none';
      });
    }

    // Close modal when clicking outside the image
    window.addEventListener('click', (e) => {
      if (e.target === modal) {
        (modal as HTMLElement).style.display = 'none';
      }
    });
  }
});
